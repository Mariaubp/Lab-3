import listas_modulo

def operaciones():
	l=listas_modulo.cargar()
	


operaciones()	
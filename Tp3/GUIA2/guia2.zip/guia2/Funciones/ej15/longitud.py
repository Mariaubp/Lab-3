def longitud1(nombre1):
	cont1=len(nombre1)
	return cont1



def longitud2(nombre2):
	cont2=len(nombre2)
	return cont2



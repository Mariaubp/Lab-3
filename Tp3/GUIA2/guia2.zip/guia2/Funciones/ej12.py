def suma():
  for x in range (0,5) :
    num1=int(input("Ingrese el primer valor:"))
    num2=int(input("Ingrese el segundo valor:"))
    suma=num1+num2
    print("La suma de los pares de numeros es ",suma)
    print("----------------------------")

print("Programa de carga de 5 pares de numeros")
suma()
print("Fin del programa")
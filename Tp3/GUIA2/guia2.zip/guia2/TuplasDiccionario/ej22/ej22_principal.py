

import operaciones
diccionario= {"Argentina": 120000, "Brasil": 500000, "Chile": 80000, "Uruguay": 5000}


def datos(diccionario):
	m=operaciones.mostrar(diccionario)



mostrarDatos= datos(diccionario)







def mostrar(diccionario):
	print("Elementos del Diccionario")
	for clave in diccionario:
		print(clave, ":", diccionario[clave])



